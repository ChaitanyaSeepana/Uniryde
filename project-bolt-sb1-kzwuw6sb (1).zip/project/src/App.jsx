import React, { useState, useEffect } from 'react';
import { createClient } from '@supabase/supabase-js';

const supabase = createClient(
  import.meta.env.VITE_SUPABASE_URL,
  import.meta.env.VITE_SUPABASE_ANON_KEY
);

function App() {
  const [rides, setRides] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    fetchRides();
  }, []);

  const fetchRides = async () => {
    try {
      const response = await fetch('http://localhost:3000/api/rides');
      if (!response.ok) {
        throw new Error('Failed to fetch rides');
      }
      const data = await response.json();
      setRides(data);
    } catch (err) {
      console.error('Error fetching rides:', err);
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-100 flex items-center justify-center">
        <p className="text-xl">Loading rides...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gray-100 flex items-center justify-center">
        <p className="text-xl text-red-600">Error: {error}</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-100">
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-8">UniRyde</h1>
        <div className="grid gap-4">
          {rides.length === 0 ? (
            <p className="text-gray-600">No rides available</p>
          ) : (
            rides.map(ride => (
              <div key={ride.id} className="bg-white p-4 rounded-lg shadow">
                <h2 className="text-xl font-semibold">{ride.from_location} → {ride.to_location}</h2>
                <p className="text-gray-600">Available seats: {ride.available_seats}</p>
                <p className="text-gray-600">
                  Departure: {new Date(ride.departure_time).toLocaleString()}
                </p>
                {ride.price && (
                  <p className="text-gray-600">Price: ${ride.price}</p>
                )}
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}

export default App;