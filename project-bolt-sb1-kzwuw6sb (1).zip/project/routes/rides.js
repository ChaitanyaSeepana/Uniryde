import express from 'express';
import { createClient } from '@supabase/supabase-js';

const router = express.Router();

const supabase = createClient(
  process.env.VITE_SUPABASE_URL,
  process.env.VITE_SUPABASE_ANON_KEY
);

// Create a new ride
router.post('/', async (req, res) => {
  try {
    const { from_location, to_location, departure_time, available_seats, user_id, price } = req.body;
    const { data, error } = await supabase
      .from('rides')
      .insert([
        { 
          from_location,
          to_location,
          departure_time,
          available_seats,
          user_id,
          price
        }
      ])
      .select();

    if (error) throw error;
    res.json(data);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get all available rides
router.get('/', async (req, res) => {
  try {
    const { data, error } = await supabase
      .from('rides')
      .select('*')
      .gt('available_seats', 0)
      .order('departure_time', { ascending: true });

    if (error) throw error;
    res.json(data);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get ride by ID
router.get('/:id', async (req, res) => {
  try {
    const { data, error } = await supabase
      .from('rides')
      .select('*')
      .eq('id', req.params.id)
      .single();

    if (error) throw error;
    res.json(data);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

export { router as default };

export default supabase