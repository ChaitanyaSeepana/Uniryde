import express from 'express';
import { createClient } from '@supabase/supabase-js';

const router = express.Router();

const supabase = createClient(
  process.env.VITE_SUPABASE_URL,
  process.env.VITE_SUPABASE_ANON_KEY
);

// Create a new booking
router.post('/', async (req, res) => {
  try {
    const { ride_id, user_id } = req.body;
    
    // Check seat availability
    const { data: ride, error: rideError } = await supabase
      .from('rides')
      .select('available_seats')
      .eq('id', ride_id)
      .single();

    if (rideError) throw rideError;
    if (ride.available_seats <= 0) {
      return res.status(400).json({ error: 'No seats available' });
    }

    // Create booking
    const { data: booking, error: bookingError } = await supabase
      .from('bookings')
      .insert([
        { ride_id, user_id, status: 'confirmed' }
      ])
      .select();

    if (bookingError) throw bookingError;

    // Update available seats
    const { error: updateError } = await supabase
      .from('rides')
      .update({ available_seats: ride.available_seats - 1 })
      .eq('id', ride_id);

    if (updateError) throw updateError;

    res.json(booking);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get user's bookings
router.get('/user/:userId', async (req, res) => {
  try {
    const { data, error } = await supabase
      .from('bookings')
      .select(`
        *,
        rides (*)
      `)
      .eq('user_id', req.params.userId);

    if (error) throw error;
    res.json(data);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

export { router as default };

export default supabase