/*
  # Initial Schema Setup for Uniryde

  1. New Tables
    - users (managed by Supabase Auth)
    - rides
      - id (uuid, primary key)
      - user_id (uuid, references auth.users)
      - from_location (text)
      - to_location (text)
      - departure_time (timestamptz)
      - available_seats (int)
      - created_at (timestamptz)
    - bookings
      - id (uuid, primary key)
      - user_id (uuid, references auth.users)
      - ride_id (uuid, references rides)
      - status (text)
      - created_at (timestamptz)

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users
*/

-- Create rides table
CREATE TABLE rides (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users NOT NULL,
  from_location text NOT NULL,
  to_location text NOT NULL,
  departure_time timestamptz NOT NULL,
  available_seats int NOT NULL CHECK (available_seats >= 0),
  created_at timestamptz DEFAULT now(),
  distance float,
  price decimal(10,2)
);

-- Create bookings table
CREATE TABLE bookings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users NOT NULL,
  ride_id uuid REFERENCES rides NOT NULL,
  status text NOT NULL CHECK (status IN ('pending', 'confirmed', 'cancelled')),
  created_at timestamptz DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE rides ENABLE ROW LEVEL SECURITY;
ALTER TABLE bookings ENABLE ROW LEVEL SECURITY;

-- Policies for rides table
CREATE POLICY "Users can view all rides" 
  ON rides FOR SELECT 
  TO authenticated 
  USING (true);

CREATE POLICY "Users can create rides" 
  ON rides FOR INSERT 
  TO authenticated 
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Only ride creator can update their rides" 
  ON rides FOR UPDATE 
  TO authenticated 
  USING (auth.uid() = user_id);

-- Policies for bookings table
CREATE POLICY "Users can view their own bookings" 
  ON bookings FOR SELECT 
  TO authenticated 
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create bookings" 
  ON bookings FOR INSERT 
  TO authenticated 
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own bookings" 
  ON bookings FOR UPDATE 
  TO authenticated 
  USING (auth.uid() = user_id);