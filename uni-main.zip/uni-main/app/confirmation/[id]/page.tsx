"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { CheckCircle, ArrowLeft, Share2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { getRideSlotById, isEligibleForFreeRide, getUserRideCount } from "@/lib/database"
import { isAuthenticated, getCurrentUser } from "@/lib/simple-auth"

export default function ConfirmationPage({ params }: { params: { id: string } }) {
  const router = useRouter()
  const [rideDetails, setRideDetails] = useState<any | null>(null)
  const [loading, setLoading] = useState(true)
  const [mounted, setMounted] = useState(false)
  const [freeRidesLeft, setFreeRidesLeft] = useState(0)
  const [wasFreeTide, setWasFreeTide] = useState(false)

  useEffect(() => {
    setMounted(true)

    // Check if user is logged in
    if (!isAuthenticated()) {
      router.push("/login")
      return
    }

    const currentUser = getCurrentUser()
    if (!currentUser) {
      router.push("/login")
      return
    }

    // Fetch ride details
    setLoading(true)
    const rideSlot = getRideSlotById(params.id)

    if (!rideSlot) {
      router.push("/home")
      return
    }

    // Check if this was a free ride
    const wasFree = isEligibleForFreeRide(currentUser.id)
    setWasFreeTide(wasFree)

    // Calculate free rides left
    const rideCount = getUserRideCount(currentUser.id)
    const ridesLeft = Math.max(0, 3 - rideCount)
    setFreeRidesLeft(ridesLeft)

    setRideDetails({
      id: rideSlot.id,
      date: rideSlot.date,
      time: rideSlot.time,
      from: rideSlot.from,
      to: rideSlot.to,
      price: wasFree ? 0 : rideSlot.price,
    })

    setLoading(false)
  }, [params.id, router])

  // Don't render anything until client-side
  if (!mounted) return null

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-purple-500"></div>
      </div>
    )
  }

  if (!rideDetails) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <div className="text-center">
          <h2 className="text-xl font-semibold">Ride not found</h2>
          <Button className="mt-4" onClick={() => router.push("/home")}>
            Go back home
          </Button>
        </div>
      </div>
    )
  }

  return (
    <main className="flex min-h-screen flex-col bg-white">
      <header className="p-4 flex items-center justify-between">
        <Button variant="ghost" size="icon" onClick={() => router.push("/home")}>
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <Button variant="ghost" size="icon">
          <Share2 className="h-5 w-5" />
        </Button>
      </header>

      <div className="flex-1 flex flex-col items-center justify-center p-6">
        <div className="w-20 h-20 rounded-full bg-green-100 flex items-center justify-center mb-6">
          <CheckCircle className="h-12 w-12 text-green-500" />
        </div>

        <h1 className="text-2xl font-bold mb-2">Booking Confirmed!</h1>
        <p className="text-gray-500 text-center mb-4">Your ride has been successfully booked.</p>

        {wasFreeTide && (
          <div className="bg-green-100 text-green-800 p-3 rounded-lg text-center mb-4">
            <p className="font-bold">FREE RIDE USED!</p>
            <p className="text-sm">{freeRidesLeft} free rides remaining</p>
          </div>
        )}

        <div className="w-full max-w-md bg-gray-50 rounded-xl p-5 mb-6">
          <div className="flex justify-between mb-3">
            <span className="text-gray-600">Booking ID</span>
            <span className="font-medium">#{rideDetails.id}12345</span>
          </div>
          <div className="flex justify-between mb-3">
            <span className="text-gray-600">Date & Time</span>
            <span className="font-medium">
              {rideDetails.date}, {rideDetails.time}
            </span>
          </div>
          <div className="flex justify-between mb-3">
            <span className="text-gray-600">From</span>
            <span className="font-medium">{rideDetails.from}</span>
          </div>
          <div className="flex justify-between mb-3">
            <span className="text-gray-600">To</span>
            <span className="font-medium">{rideDetails.to}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-600">Amount Paid</span>
            <span className="font-medium">
              {wasFreeTide ? <span className="text-green-600 font-bold">FREE</span> : `₹${rideDetails.price}`}
            </span>
          </div>
        </div>

        <Button
          className="w-full max-w-md bg-purple-600 hover:bg-purple-700 text-white"
          onClick={() => router.push("/home")}
        >
          Back to Home
        </Button>
      </div>
    </main>
  )
}

