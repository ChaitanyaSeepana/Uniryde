"use client"

import { useRouter } from "next/navigation"
import { useState, useEffect } from "react"
import { getRidesByUser, getRidesJoinedByUser } from "@/lib/database"
import type { RideSlot } from "@/types"
import { isAuthenticated, getCurrentUser, logout } from "@/lib/simple-auth"
import Link from "next/link"

export default function ProfilePage() {
  const router = useRouter()
  const [activeTab, setActiveTab] = useState("account")
  const [isLoading, setIsLoading] = useState(true)
  const [mounted, setMounted] = useState(false)
  const [userRides, setUserRides] = useState<RideSlot[]>([])
  const [joinedRides, setJoinedRides] = useState<RideSlot[]>([])
  const [user, setUser] = useState<{ name: string; email: string } | null>(null)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    setMounted(true)

    const checkAuthAndLoadData = async () => {
      try {
        // Check if user is authenticated
        if (!isAuthenticated()) {
          router.push("/login")
          return
        }

        // Get current user
        const currentUser = getCurrentUser()

        if (!currentUser) {
          router.push("/login")
          return
        }

        setUser({
          name: currentUser.name,
          email: currentUser.email,
        })

        // Load user's rides
        try {
          const createdRides = await getRidesByUser(currentUser.id)
          // Ensure we always have an array, even if the API returns null or undefined
          setUserRides(Array.isArray(createdRides) ? createdRides : [])
        } catch (error) {
          console.error("Error loading created rides:", error)
          setUserRides([])
        }

        // Load rides joined by the user
        try {
          const rides = await getRidesJoinedByUser(currentUser.id)
          // Ensure we always have an array, even if the API returns null or undefined
          setJoinedRides(Array.isArray(rides) ? rides : [])
        } catch (error) {
          console.error("Error loading joined rides:", error)
          setJoinedRides([])
        }
      } catch (error) {
        console.error("Error loading data:", error)
        setError("Failed to load profile data. Please try again.")
      } finally {
        setIsLoading(false)
      }
    }

    checkAuthAndLoadData()
  }, [router])

  function handleLogout() {
    try {
      logout()
      router.push("/login")
    } catch (error) {
      console.error("Error logging out:", error)
    }
  }

  // Don't render anything until client-side
  if (!mounted) return null

  if (isLoading) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-purple-500"></div>
      </div>
    )
  }

  if (error) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <div className="text-center">
          <h2 className="text-xl font-semibold text-red-600 mb-4">Error</h2>
          <p className="mb-4">{error}</p>
          <button onClick={() => router.push("/home")} className="bg-blue-500 text-white px-4 py-2 rounded">
            Return to Home
          </button>
        </div>
      </div>
    )
  }

  return (
    <main className="flex min-h-screen flex-col bg-white">
      <header className="p-4 flex items-center justify-between">
        <div className="flex items-center">
          <button onClick={() => router.back()} className="mr-2 p-2 rounded-full hover:bg-gray-100">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="20"
              height="20"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <path d="m12 19-7-7 7-7" />
              <path d="M19 12H5" />
            </svg>
          </button>
          <h1 className="font-semibold text-lg">Uniryde Account</h1>
        </div>
      </header>

      <div className="w-full border-b">
        <div className="grid w-full grid-cols-3">
          <button
            className={`py-2 text-center ${activeTab === "account" ? "border-b-2 border-blue-500 font-medium" : ""}`}
            onClick={() => setActiveTab("account")}
          >
            Account Info
          </button>
          <button
            className={`py-2 text-center ${activeTab === "rides" ? "border-b-2 border-blue-500 font-medium" : ""}`}
            onClick={() => setActiveTab("rides")}
          >
            My Rides
          </button>
          <button
            className={`py-2 text-center ${activeTab === "joined" ? "border-b-2 border-blue-500 font-medium" : ""}`}
            onClick={() => setActiveTab("joined")}
          >
            Joined Rides
          </button>
        </div>
      </div>

      {activeTab === "account" && user && (
        <div className="p-4">
          <div className="flex flex-col items-center mb-6">
            <div className="h-24 w-24 rounded-full bg-gray-200 flex items-center justify-center text-3xl text-gray-500">
              {user.name.charAt(0)}
            </div>
            <h2 className="text-xl font-semibold mt-3">{user.name}</h2>
            <p className="text-sm text-gray-500">{user.email}</p>
          </div>

          <div className="mb-6">
            <h3 className="font-semibold mb-3">Account Info</h3>
            <div className="bg-gray-50 rounded-xl p-4">
              <div className="space-y-4">
                <div>
                  <p className="text-sm text-gray-500">Name</p>
                  <p className="font-medium">{user.name}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500">Email</p>
                  <div className="flex items-center">
                    <p className="font-medium">{user.email}</p>
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="16"
                      height="16"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="text-green-500 ml-2"
                    >
                      <path d="M20 6 9 17l-5-5" />
                    </svg>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="space-y-3">
            <button className="w-full mt-6 bg-red-500 text-white py-2 rounded-lg" onClick={handleLogout}>
              Logout
            </button>
          </div>
        </div>
      )}

      {activeTab === "rides" && (
        <div className="p-4">
          <h3 className="font-semibold mb-3">My Created Rides</h3>

          {userRides.length === 0 ? (
            <div className="bg-gray-50 rounded-xl p-4 text-center">
              <p className="text-gray-500">You haven't created any rides yet</p>
              <Link href="/create-ride" className="mt-2 inline-block bg-blue-500 text-white px-4 py-2 rounded">
                Create a Ride
              </Link>
            </div>
          ) : (
            <div className="space-y-3">
              {userRides.map((ride) => (
                <Link
                  key={ride.id}
                  href={`/ride/${ride.id}`}
                  className="block bg-white rounded-xl p-3 shadow-sm border border-gray-100"
                >
                  <div className="flex justify-between items-center">
                    <div>
                      <div className="font-semibold">
                        {ride.time} - {ride.date}
                      </div>
                      <div className="text-sm text-gray-600">
                        {ride.from} → {ride.to}
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-xs text-gray-500">Riders</div>
                      <div className="text-xs font-semibold">
                        {ride.riders.length}/{ride.maxRiders}
                      </div>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          )}
        </div>
      )}

      {activeTab === "joined" && (
        <div className="p-4">
          <h3 className="font-semibold mb-3">Rides I've Joined</h3>

          {joinedRides.length === 0 ? (
            <div className="bg-gray-50 rounded-xl p-4 text-center">
              <p className="text-gray-500">You haven't joined any rides yet</p>
              <Link href="/home" className="mt-2 inline-block bg-blue-500 text-white px-4 py-2 rounded">
                Find Rides
              </Link>
            </div>
          ) : (
            <div className="space-y-3">
              {joinedRides.map((ride) => (
                <Link
                  key={ride.id}
                  href={`/ride/${ride.id}`}
                  className="block bg-white rounded-xl p-3 shadow-sm border border-gray-100"
                >
                  <div className="flex justify-between items-center">
                    <div>
                      <div className="font-semibold">
                        {ride.time} - {ride.date}
                      </div>
                      <div className="text-sm text-gray-600">
                        {ride.from} → {ride.to}
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-xs text-gray-500">Riders</div>
                      <div className="text-xs font-semibold">
                        {ride.riders.length}/{ride.maxRiders}
                      </div>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          )}
        </div>
      )}
    </main>
  )
}

