"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { ArrowLeft, CreditCard, Wallet } from "lucide-react"
import { Button } from "@/components/ui/button"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { getRideSlotById, getRidePriceForUser, isEligibleForFreeRide } from "@/lib/database"
import { getCurrentUser, isAuthenticated } from "@/lib/simple-auth"

export default function PaymentPage({ params }: { params: { id: string } }) {
  const router = useRouter()
  const [rideDetails, setRideDetails] = useState<any | null>(null)
  const [loading, setLoading] = useState(true)
  const [paymentMethod, setPaymentMethod] = useState<"card" | "wallet" | "free">("card")
  const [processing, setProcessing] = useState(false)
  const [mounted, setMounted] = useState(false)
  const [isFreeRide, setIsFreeRide] = useState(false)
  const [ridePrice, setRidePrice] = useState(0)

  useEffect(() => {
    setMounted(true)

    // Check if user is logged in
    if (!isAuthenticated()) {
      router.push("/login")
      return
    }

    const currentUser = getCurrentUser()
    if (!currentUser) {
      router.push("/login")
      return
    }

    // Fetch ride details
    setLoading(true)
    const rideSlot = getRideSlotById(params.id)

    if (!rideSlot) {
      router.push("/home")
      return
    }

    // Check if eligible for free ride
    const isFree = isEligibleForFreeRide(currentUser.id)
    setIsFreeRide(isFree)

    if (isFree) {
      setPaymentMethod("free")
    }

    // Get ride price for user
    const price = getRidePriceForUser(currentUser.id, rideSlot.price)
    setRidePrice(price)

    setRideDetails({
      id: rideSlot.id,
      date: rideSlot.date,
      time: rideSlot.time,
      from: rideSlot.from,
      to: rideSlot.to,
      price: price,
    })

    setLoading(false)
  }, [params.id, router])

  // Don't render anything until client-side
  if (!mounted) return null

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-purple-500"></div>
      </div>
    )
  }

  if (!rideDetails) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <div className="text-center">
          <h2 className="text-xl font-semibold">Ride not found</h2>
          <Button className="mt-4" onClick={() => router.push("/home")}>
            Go back home
          </Button>
        </div>
      </div>
    )
  }

  const handlePayment = () => {
    setProcessing(true)
    // Simulate payment processing
    setTimeout(() => {
      setProcessing(false)
      router.push(`/confirmation/${params.id}`)
    }, 1500)
  }

  return (
    <main className="flex min-h-screen flex-col bg-white">
      <header className="p-4 flex items-center">
        <Button variant="ghost" size="icon" onClick={() => router.back()} className="mr-2">
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <h1 className="font-semibold text-lg">Payment</h1>
      </header>

      <div className="p-4 flex-1">
        <div className="mb-6">
          <h2 className="text-xl font-semibold">Ride Summary</h2>
          <div className="mt-3 bg-gray-50 rounded-xl p-4">
            <div className="flex justify-between mb-2">
              <span className="text-gray-600">Date & Time</span>
              <span className="font-medium">
                {rideDetails.date}, {rideDetails.time}
              </span>
            </div>
            <div className="flex justify-between mb-2">
              <span className="text-gray-600">From</span>
              <span className="font-medium">{rideDetails.from}</span>
            </div>
            <div className="flex justify-between mb-2">
              <span className="text-gray-600">To</span>
              <span className="font-medium">{rideDetails.to}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Price</span>
              <span className="font-medium">
                {isFreeRide ? <span className="text-green-600 font-bold">FREE</span> : `₹${rideDetails.price}`}
              </span>
            </div>
          </div>
        </div>

        {isFreeRide ? (
          <div className="bg-green-50 border border-green-200 rounded-xl p-4 mb-6">
            <div className="flex items-center gap-3">
              <div className="bg-green-100 rounded-full p-2">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="text-green-600"
                >
                  <path d="M20 6 9 17l-5-5" />
                </svg>
              </div>
              <div>
                <h3 className="font-semibold text-green-800">Free Ride Promotion</h3>
                <p className="text-sm text-green-700">You're using one of your free rides!</p>
              </div>
            </div>
          </div>
        ) : (
          <>
            <div className="mb-6">
              <h3 className="font-semibold mb-3">Payment Method</h3>
              <RadioGroup
                value={paymentMethod}
                onValueChange={(value) => setPaymentMethod(value as "card" | "wallet")}
                className="grid grid-cols-2 gap-4"
              >
                <div>
                  <RadioGroupItem value="card" id="card" className="peer sr-only" />
                  <Label
                    htmlFor="card"
                    className="flex flex-col items-center justify-between rounded-md border-2 border-muted bg-popover p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary [&:has([data-state=checked])]:border-primary"
                  >
                    <CreditCard className="mb-3 h-6 w-6" />
                    Card
                  </Label>
                </div>
                <div>
                  <RadioGroupItem value="wallet" id="wallet" className="peer sr-only" />
                  <Label
                    htmlFor="wallet"
                    className="flex flex-col items-center justify-between rounded-md border-2 border-muted bg-popover p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary [&:has([data-state=checked])]:border-primary"
                  >
                    <Wallet className="mb-3 h-6 w-6" />
                    Wallet
                  </Label>
                </div>
              </RadioGroup>
            </div>

            {paymentMethod === "card" && (
              <div className="space-y-4 mb-6">
                <div>
                  <Label htmlFor="card-name">Name on Card</Label>
                  <Input id="card-name" placeholder="John Doe" />
                </div>
                <div>
                  <Label htmlFor="card-number">Card Number</Label>
                  <Input id="card-number" placeholder="1234 5678 9012 3456" />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="expiry">Expiry Date</Label>
                    <Input id="expiry" placeholder="MM/YY" />
                  </div>
                  <div>
                    <Label htmlFor="cvv">CVV</Label>
                    <Input id="cvv" placeholder="123" />
                  </div>
                </div>
              </div>
            )}

            {paymentMethod === "wallet" && (
              <div className="bg-gray-50 rounded-xl p-4 mb-6">
                <div className="flex justify-between items-center mb-3">
                  <span className="font-medium">Wallet Balance</span>
                  <span className="font-semibold">₹100</span>
                </div>
                <Button variant="outline" className="w-full">
                  Add Money
                </Button>
              </div>
            )}
          </>
        )}

        <Button
          className={`w-full ${isFreeRide ? "bg-green-500 hover:bg-green-600" : "bg-blue-500 hover:bg-blue-600"} text-white`}
          onClick={handlePayment}
          disabled={processing}
        >
          {processing ? "Processing..." : isFreeRide ? "Confirm Free Ride" : `Pay ₹${rideDetails.price}`}
        </Button>
      </div>
    </main>
  )
}

