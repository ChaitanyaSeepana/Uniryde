"use client"

import type React from "react"
import { useRouter, useSearchParams } from "next/navigation"
import { useState, useEffect } from "react"
import { createRideSlot } from "@/lib/database"
import { getCurrentUser, isAuthenticated } from "@/lib/simple-auth"
import MapIntegration from "@/components/map-integration"
import { GOOGLE_MAPS_API_KEY } from "@/lib/config"
import { Button } from "@/components/ui/button"
import { Loader2 } from "lucide-react"

interface Location {
  lat: number
  lng: number
  address: string
}

export default function CreateRidePage() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const [isLoading, setIsLoading] = useState(true)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [formData, setFormData] = useState({
    from: "",
    to: "",
    date: "",
    time: "",
    price: "",
    maxRiders: "4",
    meetingPoint: "",
    waitingTime: "15",
  })
  const [fromLocation, setFromLocation] = useState<Location | null>(null)
  const [toLocation, setToLocation] = useState<Location | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [step, setStep] = useState(1)
  const [mounted, setMounted] = useState(false)
  const [mapMode, setMapMode] = useState<"from" | "to">("from")

  useEffect(() => {
    setMounted(true)

    const checkAuth = async () => {
      try {
        if (!isAuthenticated()) {
          router.push("/login")
          return
        }

        // Get query params if any
        const from = searchParams.get("from")
        const to = searchParams.get("to")
        const date = searchParams.get("date")
        const time = searchParams.get("time")

        if (from || to || date || time) {
          setFormData((prev) => ({
            ...prev,
            from: from || prev.from,
            to: to || prev.to,
            date: date || prev.date,
            time: time || prev.time,
          }))
        }
      } catch (err) {
        console.error("Authentication check failed:", err)
      } finally {
        setIsLoading(false)
      }
    }

    checkAuth()
  }, [router, searchParams])

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleFromLocationSelect = (location: Location) => {
    setFromLocation(location)
    setFormData((prev) => ({ ...prev, from: location.address }))
  }

  const handleToLocationSelect = (location: Location) => {
    setToLocation(location)
    setFormData((prev) => ({ ...prev, to: location.address }))
  }

  const handleNextStep = () => {
    if (step === 1) {
      // Validate first step
      if (!formData.from || !formData.to || !formData.date || !formData.time) {
        setError("Please fill in all required fields")
        return
      }
    }

    setStep((prev) => prev + 1)
    setError(null)
  }

  const handlePrevStep = () => {
    setStep((prev) => prev - 1)
    setError(null)
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)
    setError(null)

    try {
      const currentUser = getCurrentUser()

      if (!currentUser) {
        setError("You must be logged in to create a ride")
        return
      }

      // Validate form data
      if (
        !formData.from ||
        !formData.to ||
        !formData.date ||
        !formData.time ||
        !formData.price ||
        !formData.meetingPoint
      ) {
        setError("Please fill in all required fields")
        return
      }

      // Create the ride slot
      const newSlot = await createRideSlot({
        from: formData.from,
        to: formData.to,
        date: formData.date,
        time: formData.time,
        price: Number(formData.price),
        maxRiders: Number(formData.maxRiders),
        meetingPoint: formData.meetingPoint,
        waitingTime: `${formData.waitingTime} minutes`,
        riders: [
          {
            id: currentUser.id,
            name: currentUser.name,
            email: currentUser.email,
            status: "Confirmed",
          },
        ],
        createdBy: currentUser.id,
      })

      if (!newSlot) {
        setError("Failed to create ride. Please try again.")
        return
      }

      router.push(`/ride/${newSlot.id}`)
    } catch (err) {
      console.error("Error creating ride:", err)
      setError("Failed to create ride. Please try again.")
    } finally {
      setIsSubmitting(false)
    }
  }

  if (!mounted) return null

  if (isLoading) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-purple-500"></div>
      </div>
    )
  }

  return (
    <main className="flex min-h-screen flex-col bg-white">
      <header className="p-4 flex items-center">
        <button onClick={() => router.back()} className="mr-2 p-2 rounded-full hover:bg-gray-100">
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="20"
            height="20"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <path d="m12 19-7-7 7-7" />
            <path d="M19 12H5" />
          </svg>
        </button>
        <h1 className="font-semibold text-lg">Create a New Ride</h1>
      </header>

      <div className="p-4 flex-1">
        {error && <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">{error}</div>}

        <div className="mb-6">
          <div className="flex justify-between items-center">
            {[1, 2, 3].map((s) => (
              <div key={s} className="flex flex-col items-center">
                <div
                  className={`w-8 h-8 rounded-full flex items-center justify-center ${
                    s === step
                      ? "bg-blue-500 text-white"
                      : s < step
                        ? "bg-green-500 text-white"
                        : "bg-gray-200 text-gray-500"
                  }`}
                >
                  {s < step ? (
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="16"
                      height="16"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    >
                      <path d="M20 6 9 17l-5-5" />
                    </svg>
                  ) : (
                    s
                  )}
                </div>
                <div className="text-xs mt-1">{s === 1 ? "Route" : s === 2 ? "Details" : "Confirm"}</div>
              </div>
            ))}
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          {step === 1 && (
            <>
              <div className="mb-4">
                <div className="flex justify-between mb-2">
                  <button
                    type="button"
                    onClick={() => setMapMode("from")}
                    className={`px-4 py-2 rounded-lg ${mapMode === "from" ? "bg-blue-500 text-white" : "bg-gray-200"}`}
                  >
                    From Location
                  </button>
                  <button
                    type="button"
                    onClick={() => setMapMode("to")}
                    className={`px-4 py-2 rounded-lg ${mapMode === "to" ? "bg-blue-500 text-white" : "bg-gray-200"}`}
                  >
                    To Location
                  </button>
                </div>

                <div className="mb-4">
                  {mapMode === "from" ? (
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">From</label>
                      <input
                        type="text"
                        name="from"
                        value={formData.from}
                        onChange={handleChange}
                        className="w-full px-3 py-2 border rounded-xl mb-2"
                        placeholder="Starting location"
                        required
                      />
                      <MapIntegration
                        apiKey={GOOGLE_MAPS_API_KEY}
                        height="300px"
                        showSearchBox={true}
                        initialAddress={formData.from}
                        onLocationSelect={handleFromLocationSelect}
                        markers={fromLocation ? [{ lat: fromLocation.lat, lng: fromLocation.lng }] : []}
                      />
                    </div>
                  ) : (
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">To</label>
                      <input
                        type="text"
                        name="to"
                        value={formData.to}
                        onChange={handleChange}
                        className="w-full px-3 py-2 border rounded-xl mb-2"
                        placeholder="Destination"
                        required
                      />
                      <MapIntegration
                        apiKey={GOOGLE_MAPS_API_KEY}
                        height="300px"
                        showSearchBox={true}
                        initialAddress={formData.to}
                        onLocationSelect={handleToLocationSelect}
                        markers={toLocation ? [{ lat: toLocation.lat, lng: toLocation.lng }] : []}
                      />
                    </div>
                  )}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Date</label>
                  <input
                    type="date"
                    name="date"
                    value={formData.date}
                    onChange={handleChange}
                    className="w-full px-3 py-2 border rounded-xl"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Time</label>
                  <input
                    type="time"
                    name="time"
                    value={formData.time}
                    onChange={handleChange}
                    className="w-full px-3 py-2 border rounded-xl"
                    required
                  />
                </div>
              </div>

              <Button
                type="button"
                onClick={handleNextStep}
                className="w-full bg-blue-500 text-white py-2 rounded-xl mt-6"
              >
                Next
              </Button>
            </>
          )}

          {step === 2 && (
            <>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Price (₹)</label>
                  <input
                    type="number"
                    name="price"
                    value={formData.price}
                    onChange={handleChange}
                    className="w-full px-3 py-2 border rounded-xl"
                    placeholder="10"
                    min="1"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Max Riders</label>
                  <select
                    name="maxRiders"
                    value={formData.maxRiders}
                    onChange={handleChange}
                    className="w-full px-3 py-2 border rounded-xl"
                    required
                  >
                    <option value="2">2</option>
                    <option value="3">3</option>
                    <option value="4">4</option>
                    <option value="5">5</option>
                    <option value="6">6</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Meeting Point</label>
                <input
                  type="text"
                  name="meetingPoint"
                  value={formData.meetingPoint}
                  onChange={handleChange}
                  className="w-full px-3 py-2 border rounded-xl"
                  placeholder="Specific meeting location"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Waiting Time (minutes)</label>
                <input
                  type="number"
                  name="waitingTime"
                  value={formData.waitingTime}
                  onChange={handleChange}
                  className="w-full px-3 py-2 border rounded-xl"
                  placeholder="15"
                  min="5"
                  required
                />
              </div>

              <div className="flex gap-3 mt-6">
                <Button type="button" onClick={handlePrevStep} variant="outline" className="flex-1">
                  Back
                </Button>
                <Button type="button" onClick={handleNextStep} className="flex-1">
                  Next
                </Button>
              </div>
            </>
          )}

          {step === 3 && (
            <>
              <div className="bg-gray-50 rounded-xl p-4">
                <h3 className="font-semibold mb-3">Ride Summary</h3>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-gray-600">From:</span>
                    <span className="font-medium">{formData.from}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">To:</span>
                    <span className="font-medium">{formData.to}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Date & Time:</span>
                    <span className="font-medium">
                      {formData.date}, {formData.time}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Price:</span>
                    <span className="font-medium">₹{formData.price}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Max Riders:</span>
                    <span className="font-medium">{formData.maxRiders}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Meeting Point:</span>
                    <span className="font-medium">{formData.meetingPoint}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Waiting Time:</span>
                    <span className="font-medium">{formData.waitingTime} minutes</span>
                  </div>
                </div>
              </div>

              <div className="flex gap-3 mt-6">
                <Button
                  type="button"
                  onClick={handlePrevStep}
                  variant="outline"
                  className="flex-1"
                  disabled={isSubmitting}
                >
                  Back
                </Button>
                <Button type="submit" className="flex-1 bg-green-500 hover:bg-green-600" disabled={isSubmitting}>
                  {isSubmitting ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Creating...
                    </>
                  ) : (
                    "Create Ride"
                  )}
                </Button>
              </div>
            </>
          )}
        </form>
      </div>
    </main>
  )
}

