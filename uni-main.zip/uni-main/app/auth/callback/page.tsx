"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { initializeMicrosoftAuth } from "@/lib/microsoft-auth"

export default function AuthCallbackPage() {
  const router = useRouter()
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    const handleCallback = async () => {
      try {
        // Initialize MSAL and handle the redirect
        const isAuthenticated = await initializeMicrosoftAuth()

        if (isAuthenticated) {
          // Redirect to home page after successful authentication
          router.push("/home")
        } else {
          // If not authenticated, redirect to login page
          router.push("/login")
        }
      } catch (err) {
        console.error("Error handling authentication callback:", err)
        setError("Authentication failed. Please try again.")
      }
    }

    handleCallback()
  }, [router])

  if (error) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <div className="text-center">
          <h2 className="text-xl font-semibold text-red-600 mb-4">Authentication Error</h2>
          <p className="mb-4">{error}</p>
          <button onClick={() => router.push("/login")} className="bg-blue-500 text-white px-4 py-2 rounded">
            Return to Login
          </button>
        </div>
      </div>
    )
  }

  return (
    <div className="flex min-h-screen items-center justify-center">
      <div className="text-center">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-purple-500 mx-auto mb-4"></div>
        <p>Completing sign-in...</p>
      </div>
    </div>
  )
}

