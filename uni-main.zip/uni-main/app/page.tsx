import Link from "next/link"
import Image from "next/image"

export default function WelcomePage() {
  return (
    <main className="flex min-h-screen flex-col items-center justify-center p-6 bg-white">
      <div className="w-full max-w-md flex flex-col items-center justify-center gap-6">
        <div className="w-full flex justify-center">
          <Image src="/images/uniryde-logo.png" alt="Uniryde Logo" width={150} height={60} className="mb-4" />
        </div>

        <div className="w-full max-w-md">
          <Image
            src="/images/taxi-illustration.png"
            alt="Taxi Illustration"
            width={500}
            height={400}
            className="w-full h-auto"
          />
        </div>

        <div className="text-center space-y-2">
          <h1 className="text-3xl font-bold">
            Welcome to
            <br />
            UNIRYDE
          </h1>
          <p className="text-sm text-gray-600 max-w-xs mx-auto">
            Unique, affordable Rides. Explore reliable Mates. Get a cab in your price band today designed exclusively
            for university students.
          </p>
        </div>

        <div className="w-full space-y-3 mt-4">
          <Link
            href="/login"
            className="w-full bg-black text-white hover:bg-gray-800 flex items-center justify-center py-3 rounded-md"
          >
            GET STARTED
          </Link>
        </div>
      </div>
    </main>
  )
}

