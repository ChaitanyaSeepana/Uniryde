"use client"

import Link from "next/link"
import { useRouter } from "next/navigation"
import { useEffect, useState } from "react"
import {
  getRideSlotById,
  joinRideSlot,
  getRidePriceForUser,
  isEligibleForFreeRide,
  updateUserRideCount,
} from "@/lib/database"
import type { RideSlot, Rider, ChatMessage } from "@/types"
import { isAuthenticated, getCurrentUser } from "@/lib/simple-auth"
import MapIntegration from "@/components/map-integration"
import { GOOGLE_MAPS_API_KEY } from "@/lib/config"

export default function RideDetailPage({ params }: { params: { id: string } }) {
  const router = useRouter()
  const [rideDetails, setRideDetails] = useState<RideSlot | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [isJoining, setIsJoining] = useState(false)
  const [mounted, setMounted] = useState(false)
  const [userHasJoined, setUserHasJoined] = useState(false)
  const [showChat, setShowChat] = useState(false)
  const [chatMessage, setChatMessage] = useState("")
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([])
  const [showContactRequests, setShowContactRequests] = useState(false)
  const [contactRequests, setContactRequests] = useState<{ id: string; name: string }[]>([])
  const [currentUser, setCurrentUser] = useState<{ id: string; name: string } | null>(null)
  const [ridePrice, setRidePrice] = useState<number>(0)
  const [isFreeRide, setIsFreeRide] = useState(false)
  const [fromCoords, setFromCoords] = useState<{ lat: number; lng: number } | null>(null)
  const [toCoords, setToCoords] = useState<{ lat: number; lng: number } | null>(null)

  useEffect(() => {
    setMounted(true)

    const checkAuthAndLoadData = async () => {
      try {
        // Check if user is authenticated
        if (!isAuthenticated()) {
          router.push("/login")
          return
        }

        // Get current user
        const user = getCurrentUser()
        if (!user) {
          router.push("/login")
          return
        }

        setCurrentUser({
          id: user.id,
          name: user.name,
        })

        // Load ride details
        const rideSlot = await getRideSlotById(params.id)

        if (!rideSlot) {
          setError("Ride not found")
          setIsLoading(false)
          return
        }

        setRideDetails(rideSlot)

        // Ensure riders array exists before checking if user has joined
        const hasJoined =
          Array.isArray(rideSlot.riders) && rideSlot.riders.some((rider) => rider && rider.id === user.id)

        setUserHasJoined(hasJoined)

        // Check if eligible for free ride
        const isFree = await isEligibleForFreeRide(user.id)
        setIsFreeRide(isFree)

        // Get ride price for user
        const price = await getRidePriceForUser(user.id, rideSlot.price)
        setRidePrice(price)

        // Generate some mock chat messages
        const mockMessages: ChatMessage[] = [
          {
            id: "msg1",
            senderId: rideSlot.createdBy || "unknown",
            senderName:
              Array.isArray(rideSlot.riders) && rideSlot.riders.length > 0
                ? rideSlot.riders[0]?.name || "Unknown User"
                : "Unknown User",
            rideId: rideSlot.id,
            message: "Hello everyone! I'll be waiting at the meeting point.",
            timestamp: Date.now() - 3600000,
          },
        ]

        if (hasJoined && Array.isArray(rideSlot.riders) && rideSlot.riders.length > 1) {
          mockMessages.push({
            id: "msg2",
            senderId: "system",
            senderName: "System",
            rideId: rideSlot.id,
            message: "You've joined this ride. You can chat with other riders here.",
            timestamp: Date.now() - 1800000,
          })
        }

        setChatMessages(mockMessages)

        // Generate mock contact requests
        if (hasJoined && Array.isArray(rideSlot.riders)) {
          const otherRiders = rideSlot.riders.filter((r) => r && r.id !== user.id)
          if (otherRiders.length > 0 && otherRiders[0]) {
            setContactRequests([{ id: otherRiders[0].id, name: otherRiders[0].name }])
          }
        }

        // Set mock coordinates for the map
        // In a real app, these would come from geocoding the addresses
        setFromCoords({ lat: 28.4595, lng: 77.5021 }) // Greater Noida
        setToCoords({ lat: 28.5355, lng: 77.391 }) // Noida
      } catch (error) {
        console.error("Error loading data:", error)
        setError("Failed to load ride details")
      } finally {
        setIsLoading(false)
      }
    }

    checkAuthAndLoadData()
  }, [params.id, router])

  const handleJoinRide = async () => {
    try {
      setIsJoining(true)

      if (!currentUser) {
        setError("You must be logged in to join a ride")
        return
      }

      if (!rideDetails) {
        setError("Ride details not found")
        return
      }

      // Check if the ride is full
      if (rideDetails.availableSeats <= 0) {
        setError("This ride is already full")
        return
      }

      // Create a rider object
      const rider: Rider = {
        id: currentUser.id,
        name: currentUser.name,
        email: "user@example.com", // This would come from the user object in a real app
        status: "Joined",
      }

      // Join the ride
      const updatedRide = await joinRideSlot(params.id, rider)

      if (!updatedRide) {
        setError("Failed to join the ride")
        return
      }

      setRideDetails(updatedRide)
      setUserHasJoined(true)

      // Add system message to chat
      const systemMessage: ChatMessage = {
        id: `msg-${Date.now()}`,
        senderId: "system",
        senderName: "System",
        rideId: updatedRide.id,
        message: `${currentUser.name} has joined the ride.`,
        timestamp: Date.now(),
      }

      setChatMessages((prev) => [...prev, systemMessage])

      // If it's a free ride, update the user's ride count
      if (isFreeRide && currentUser) {
        updateUserRideCount(currentUser.id, (getCurrentUser()?.rideCount || 0) + 1)
      }

      // Navigate to payment page if not a free ride
      if (!isFreeRide) {
        router.push(`/payment/${params.id}`)
      }
    } catch (err) {
      console.error("Error joining ride:", err)
      setError("Failed to join the ride")
    } finally {
      setIsJoining(false)
    }
  }

  const handleSendMessage = () => {
    if (!chatMessage.trim() || !currentUser || !rideDetails) return

    const newMessage: ChatMessage = {
      id: `msg-${Date.now()}`,
      senderId: currentUser.id,
      senderName: currentUser.name,
      rideId: rideDetails.id,
      message: chatMessage,
      timestamp: Date.now(),
    }

    setChatMessages((prev) => [...prev, newMessage])
    setChatMessage("")
  }

  const handleApproveContact = (id: string) => {
    // In a real app, this would update a database
    setContactRequests((prev) => prev.filter((req) => req.id !== id))

    // Add system message to chat
    if (currentUser && rideDetails) {
      const systemMessage: ChatMessage = {
        id: `msg-${Date.now()}`,
        senderId: "system",
        senderName: "System",
        rideId: rideDetails.id,
        message: `Contact information shared.`,
        timestamp: Date.now(),
      }

      setChatMessages((prev) => [...prev, systemMessage])
    }
  }

  // Don't render anything until client-side
  if (!mounted) return null

  if (isLoading) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-purple-500"></div>
      </div>
    )
  }

  if (error || !rideDetails) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <div className="text-center">
          <h2 className="text-xl font-semibold">{error || "Ride not found"}</h2>
          <Link href="/home" className="mt-4 inline-block bg-blue-500 text-white px-4 py-2 rounded">
            Go back home
          </Link>
        </div>
      </div>
    )
  }

  return (
    <main className="flex min-h-screen flex-col bg-white">
      <header className="p-4 flex items-center">
        <button onClick={() => router.back()} className="mr-2 p-2 rounded-full hover:bg-gray-100">
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="20"
            height="20"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <path d="m12 19-7-7 7-7" />
            <path d="M19 12H5" />
          </svg>
        </button>
        <h1 className="font-semibold text-lg">Ride Details</h1>

        {userHasJoined && (
          <div className="ml-auto flex gap-2">
            <button onClick={() => setShowChat(!showChat)} className="p-2 rounded-full bg-blue-100 text-blue-600">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="20"
                height="20"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" />
              </svg>
            </button>
            <button
              onClick={() => setShowContactRequests(!showContactRequests)}
              className="p-2 rounded-full bg-green-100 text-green-600"
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="20"
                height="20"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" />
                <circle cx="9" cy="7" r="4" />
                <path d="M22 21v-2a4 4 0 0 0-3-3.87" />
                <path d="M16 3.13a4 4 0 0 1 0 7.75" />
              </svg>
            </button>
          </div>
        )}
      </header>

      {showChat && userHasJoined && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-xl w-full max-w-md h-[80vh] flex flex-col">
            <div className="p-4 border-b flex justify-between items-center">
              <h2 className="font-semibold">Ride Chat</h2>
              <button onClick={() => setShowChat(false)} className="p-1 rounded-full hover:bg-gray-100">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="20"
                  height="20"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <path d="M18 6 6 18" />
                  <path d="m6 6 12 12" />
                </svg>
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-4 space-y-3">
              {chatMessages.map((msg) => (
                <div
                  key={msg.id}
                  className={`${
                    msg.senderId === "system"
                      ? "bg-gray-100 text-gray-700"
                      : msg.senderId === currentUser?.id
                        ? "bg-blue-100 text-blue-800 ml-auto"
                        : "bg-gray-200"
                  } p-3 rounded-lg max-w-[80%] ${msg.senderId === currentUser?.id ? "ml-auto" : ""}`}
                >
                  {msg.senderId !== currentUser?.id && msg.senderId !== "system" && (
                    <p className="text-xs font-semibold">{msg.senderName}</p>
                  )}
                  <p>{msg.message}</p>
                  <p className="text-xs text-gray-500 mt-1">
                    {new Date(msg.timestamp).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                  </p>
                </div>
              ))}
            </div>

            <div className="p-3 border-t flex gap-2">
              <input
                type="text"
                value={chatMessage}
                onChange={(e) => setChatMessage(e.target.value)}
                placeholder="Type a message..."
                className="flex-1 border rounded-full px-4 py-2"
              />
              <button onClick={handleSendMessage} className="bg-blue-500 text-white rounded-full p-2">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="20"
                  height="20"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <path d="m22 2-7 20-4-9-9-4Z" />
                  <path d="M22 2 11 13" />
                </svg>
              </button>
            </div>
          </div>
        </div>
      )}

      {showContactRequests && userHasJoined && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-xl w-full max-w-md p-4">
            <div className="flex justify-between items-center mb-4">
              <h2 className="font-semibold">Contact Requests</h2>
              <button onClick={() => setShowContactRequests(false)} className="p-1 rounded-full hover:bg-gray-100">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="20"
                  height="20"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <path d="M18 6 6 18" />
                  <path d="m6 6 12 12" />
                </svg>
              </button>
            </div>

            {contactRequests.length === 0 ? (
              <p className="text-center text-gray-500 py-4">No contact requests</p>
            ) : (
              <div className="space-y-3">
                {contactRequests.map((req) => (
                  <div key={req.id} className="border rounded-lg p-3 flex justify-between items-center">
                    <div>
                      <p className="font-medium">{req.name}</p>
                      <p className="text-sm text-gray-500">Wants to share contact info</p>
                    </div>
                    <div className="flex gap-2">
                      <button
                        onClick={() => handleApproveContact(req.id)}
                        className="bg-green-500 text-white px-3 py-1 rounded-md text-sm"
                      >
                        Approve
                      </button>
                      <button
                        onClick={() => setContactRequests((prev) => prev.filter((r) => r.id !== req.id))}
                        className="bg-gray-200 px-3 py-1 rounded-md text-sm"
                      >
                        Decline
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      <div className="h-64 w-full">
        {fromCoords && toCoords && (
          <MapIntegration
            apiKey={GOOGLE_MAPS_API_KEY}
            height="100%"
            markers={[
              { lat: fromCoords.lat, lng: fromCoords.lng, label: "A" },
              { lat: toCoords.lat, lng: toCoords.lng, label: "B" },
            ]}
          />
        )}
      </div>

      <div className="p-4">
        <div className="mb-6">
          <h2 className="text-xl font-semibold">
            {rideDetails.date}, {rideDetails.time}
          </h2>
          <p className="text-sm text-gray-500">Waiting Time: {rideDetails.waitingTime}</p>
        </div>

        <div className="space-y-4 mb-6">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-full bg-blue-500 flex items-center justify-center">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="16"
                height="16"
                viewBox="0 0 24 24"
                fill="none"
                stroke="white"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z" />
                <circle cx="12" cy="10" r="3" />
              </svg>
            </div>
            <div>
              <p className="text-sm text-gray-500">{rideDetails.from}</p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-full bg-orange-500 flex items-center justify-center">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="16"
                height="16"
                viewBox="0 0 24 24"
                fill="none"
                stroke="white"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z" />
                <circle cx="12" cy="10" r="3" />
              </svg>
            </div>
            <div>
              <p className="text-sm text-gray-500">{rideDetails.to}</p>
            </div>
          </div>
        </div>

        <div className="bg-gray-50 rounded-xl p-4 mb-6">
          <h3 className="font-semibold mb-2">Meeting Point</h3>
          <p className="text-gray-700">{rideDetails.meetingPoint}</p>
        </div>

        <div className="mb-6">
          <div className="flex justify-between items-center mb-2">
            <h3 className="font-semibold">Riders</h3>
            <span className="text-sm text-gray-500">
              {Array.isArray(rideDetails.riders) ? rideDetails.riders.length : 0}/{rideDetails.maxRiders}
            </span>
          </div>
          <div className="space-y-3">
            {Array.isArray(rideDetails.riders) &&
              rideDetails.riders.map(
                (rider) =>
                  rider && (
                    <div key={rider.id} className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="h-8 w-8 rounded-full bg-gray-200 flex items-center justify-center text-xs">
                          {rider.name?.charAt(0) || "?"}
                        </div>
                        <div>
                          <p className="text-sm font-medium">{rider.name}</p>
                          <p className="text-xs text-gray-500">{rider.email}</p>
                        </div>
                      </div>
                      <div
                        className={`px-2 py-1 rounded-full text-xs font-medium
                      ${rider.status === "Confirmed" ? "bg-green-100 text-green-800" : ""}
                      ${rider.status === "Joining" ? "bg-yellow-100 text-yellow-800" : ""}
                      ${rider.status === "Joined" ? "bg-blue-100 text-blue-800" : ""}
                    `}
                      >
                        {rider.status}
                      </div>
                    </div>
                  ),
              )}
          </div>
        </div>

        {userHasJoined ? (
          <div className="space-y-4">
            <div className="bg-green-100 text-green-800 p-3 rounded-lg text-center">
              You have joined this ride
              {isFreeRide && <div className="text-sm font-bold mt-1">FREE RIDE!</div>}
            </div>

            <div className="grid grid-cols-2 gap-4">
              <a
                href="https://m.uber.com"
                target="_blank"
                rel="noopener noreferrer"
                className="bg-black text-white py-2 rounded flex items-center justify-center"
              >
                Open Uber
              </a>
              <a
                href="https://rapido.bike"
                target="_blank"
                rel="noopener noreferrer"
                className="bg-yellow-500 text-white py-2 rounded flex items-center justify-center"
              >
                Open Rapido
              </a>
            </div>
          </div>
        ) : (
          <div className="space-y-4">
            {isFreeRide && (
              <div className="bg-green-100 text-green-800 p-3 rounded-lg text-center font-bold">
                FREE RIDE! (1 of 3 free rides)
              </div>
            )}

            <button
              onClick={handleJoinRide}
              disabled={isJoining || rideDetails.availableSeats <= 0}
              className={`w-full py-2 rounded flex items-center justify-center
                ${
                  rideDetails.availableSeats <= 0
                    ? "bg-gray-300 text-gray-500"
                    : "bg-green-500 hover:bg-green-600 text-white"
                }`}
            >
              {isJoining
                ? "Joining..."
                : rideDetails.availableSeats <= 0
                  ? "Ride Full"
                  : `Join Ride (${isFreeRide ? "FREE" : `₹${ridePrice}`})`}
            </button>
          </div>
        )}
      </div>
    </main>
  )
}

