export interface User {
  id: string
  name: string
  email: string
  avatar: string | null
  rideCount?: number
}

export interface Rider {
  id: string
  name: string
  email: string
  status: "Confirmed" | "Joining" | "Joined"
}

export interface RideSlot {
  id: string
  time: string
  from: string
  to: string
  price: number
  date: string
  waitingTime?: string
  riders: Rider[]
  createdBy: string
  maxRiders: number
  meetingPoint: string
  availableSeats: number
}

export interface RideDatabase {
  slots: RideSlot[]
  userRides: Record<string, string[]>
  joinedRides: Record<string, string[]>
  userRideCount: Record<string, number>
}

export interface ChatMessage {
  id: string
  senderId: string
  senderName: string
  rideId: string
  message: string
  timestamp: number
}

